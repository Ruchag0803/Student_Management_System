CREATE DATABASE IF NOT EXISTS SMS;
USE SMS;

-- Table to store user login credentials
CREATE TABLE IF NOT EXISTS userlogin (
    uname VARCHAR(20) PRIMARY KEY,
    password VARCHAR(10)
);

-- Table to store attendance and grades for Subject 1
CREATE TABLE IF NOT EXISTS subject1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20),
    attendance INT,
    lectureConducted INT,
    grades VARCHAR(20),
    FOREIGN KEY (username) REFERENCES userlogin(uname)
);

-- Table to store attendance and grades for Subject 2
CREATE TABLE IF NOT EXISTS subject2 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20),
    attendance INT,
    lectureConducted INT,
    grades VARCHAR(20),
    FOREIGN KEY (username) REFERENCES userlogin(uname)
);

-- Repeat the above process for additional subjects (subject3, subject4, etc.)
-- Table to store attendance and grades for Subject 3
CREATE TABLE IF NOT EXISTS subject3 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20),
    attendance INT,
    lectureConducted INT,
    grades VARCHAR(20),
    FOREIGN KEY (username) REFERENCES userlogin(uname)
);

-- Table to store attendance and grades for Subject 4
CREATE TABLE IF NOT EXISTS subject4 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20),
    attendance INT,
    lectureConducted INT,
    grades VARCHAR(20),
    FOREIGN KEY (username) REFERENCES userlogin(uname)
);


-- Inserting values for student logins
INSERT INTO userlogin VALUES ('3001@mgm.ac.in','12345');
INSERT INTO userlogin VALUES ('3002@mgm.ac.in', 'password');
INSERT INTO userlogin VALUES ('3003@mgm.ac.in', 'securepass');
INSERT INTO userlogin VALUES ('3004@mgm.ac.in', 'userlogi');
INSERT INTO userlogin VALUES ('3005@mgm.ac.in', 'qwerty');
INSERT INTO userlogin VALUES ('3006@mgm.ac.in', 'letmein');
INSERT INTO userlogin VALUES ('3007@mgm.ac.in', 'mypass');
INSERT INTO userlogin VALUES ('3008@mgm.ac.in', 'strong');
INSERT INTO userlogin VALUES ('3009@mgm.ac.in', 'secret123');
INSERT INTO userlogin VALUES ('3010@mgm.ac.in', 'password');
INSERT INTO userlogin VALUES ('3011@mgm.ac.in', 'demo123');

-- Inserting values for teacher logins
INSERT INTO userlogin (uname, password) VALUES ('teac1@mgmfac.ac.in', 'abcd');
INSERT INTO userlogin (uname, password) VALUES ('teac2@mgmfac.ac.in', '1234');
INSERT INTO userlogin (uname, password) VALUES ('teac3@mgmfac.ac.in', 'pass987');
INSERT INTO userlogin (uname, password) VALUES ('teac4@mgmfac.ac.in', 'xyz');
INSERT INTO userlogin (uname, password) VALUES ('teac5@mgmfac.ac.in', 'teacher');
INSERT INTO userlogin (uname, password) VALUES ('teac6@mgmfac.ac.in', 'pass123');

-- Inserting sample data into subject1 for attendance
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3001@mgm.ac.in', 8, 20, 'A');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3002@mgm.ac.in', 19, 20, 'B');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3003@mgm.ac.in', 15, 20, 'C');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3004@mgm.ac.in', 18, 20, 'B');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3005@mgm.ac.in', 15, 20, 'A');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3006@mgm.ac.in', 17, 20, 'C');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3007@mgm.ac.in', 18, 20, 'B');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3008@mgm.ac.in', 15, 20, 'A');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3009@mgm.ac.in', 19, 20, 'A');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3010@mgm.ac.in', 15, 20, 'C');
INSERT INTO subject1 (username, attendance, lectureConducted, grades) VALUES ('3011@mgm.ac.in', 15, 20, 'B');


INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3001@mgm.ac.in', 15, 30, 'A');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3002@mgm.ac.in', 25, 30, 'B');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3003@mgm.ac.in', 20, 30, 'C');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3004@mgm.ac.in', 24, 30, 'B');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3005@mgm.ac.in', 20, 30, 'A');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3006@mgm.ac.in', 22, 30, 'C');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3007@mgm.ac.in', 24, 30, 'B');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3008@mgm.ac.in', 20, 30, 'A');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3009@mgm.ac.in', 25, 30, 'A');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3010@mgm.ac.in', 20, 30, 'C');
INSERT INTO subject2 (username, attendance, lectureConducted, grades) VALUES ('3011@mgm.ac.in', 20, 30, 'B');


INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3001@mgm.ac.in', 15, 25, 'A');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3002@mgm.ac.in', 25, 25, 'A');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3003@mgm.ac.in', 20, 25, 'C');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3004@mgm.ac.in', 24, 25, 'B');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3005@mgm.ac.in', 20, 25, 'A');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3006@mgm.ac.in', 22, 25, 'C');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3007@mgm.ac.in', 24, 25, 'B');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3008@mgm.ac.in', 20, 25, 'A');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3009@mgm.ac.in', 25, 25, 'A');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3010@mgm.ac.in', 20, 25, 'C');
INSERT INTO subject3 (username, attendance, lectureConducted, grades) VALUES ('3011@mgm.ac.in', 20, 25, 'B');


INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3001@mgm.ac.in', 15, 30, 'A');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3002@mgm.ac.in', 25, 30, 'A');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3003@mgm.ac.in', 20, 30, 'C');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3004@mgm.ac.in', 24, 30, 'B');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3005@mgm.ac.in', 20, 30, 'A');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3006@mgm.ac.in', 22, 30, 'C');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3007@mgm.ac.in', 24, 30, 'B');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3008@mgm.ac.in', 20, 30, 'A');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3009@mgm.ac.in', 25, 30, 'A');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3010@mgm.ac.in', 20, 30, 'C');
INSERT INTO subject4 (username, attendance, lectureConducted, grades) VALUES ('3011@mgm.ac.in', 20, 30, 'B');


show databases;