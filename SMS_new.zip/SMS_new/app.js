// app.js

const express = require('express');
const mysql = require('mysql');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path'); // Import the 'path' module
const prompt = require('prompt-sync')();

const app = express();

// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234567890',
    database: 'SMS'
});

// Connect to MySQL
connection.connect(function(err) {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Middleware
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());

// Serve static files from the root directory
app.use(express.static(path.join(__dirname)));

// Login route
app.post('/login', function(request, response) {
    const username = request.body.username;
    const password = request.body.password;
    if (username && password) {
        connection.query('SELECT * FROM userlogin WHERE uname = ? AND password = ?', [username, password], function(error, results, fields) {
            if (results.length > 0) {
                request.session.loggedin = true;
                request.session.username = username;
                response.redirect('/student_dashboard');
            } else {
                response.send('Incorrect username and/or password!');
            }			
            response.end();
        });
    } else {
        response.send('Please enter username and password!');
        response.end();
    }
});

// Student dashboard route
app.get('/student_dashboard', function(request, response) {
    if (request.session.loggedin) {
        response.send('Welcome back, ' + request.session.username + '!');
    } else {
        response.send('Please login to view this page!');
    }
    response.end();
});

// Route handler for the root URL ("/") to serve the index.html file
app.get('/', function(request, response) {
    response.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
