// dashboard.js

document.addEventListener("DOMContentLoaded", function() {
    // Fetch the username from the server's session
    fetch('/get_username')
        .then(response => response.json())
        .then(data => {
            const username = data.username;
            if (username) {
                // Update the DOM with the welcome message
                const welcomeMessage = document.createElement('p');
                welcomeMessage.textContent = 'Welcome back, ' + username + '!';
                document.querySelector('.dashboard-sections').appendChild(welcomeMessage);
            }
        })
        .catch(error => {
            console.error('Error fetching username:', error);
        });
});
